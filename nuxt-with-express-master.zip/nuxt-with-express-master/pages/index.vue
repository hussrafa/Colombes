<template>
  <div>
    <h1>Home</h1>
    <hr>

    <h3>Welcome to Express CRUD</h3>
  </div>
</template>

