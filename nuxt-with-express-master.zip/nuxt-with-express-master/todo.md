# Tasks

- [x] CRUD With Express API
- [x] Form Validations
- [x] Notifications
- [x] Authentication
- [x] Add security to API routes
- [ ] Add CORS security
- [ ] Module Relationships
- [ ] File Upload
