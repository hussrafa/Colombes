<template>
  <div>
    <h1>Home</h1>
    <hr>

    <h3>Troov-Ex</h3>
  </div>
</template>

